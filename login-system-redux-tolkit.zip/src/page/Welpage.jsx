export function welPage() {
  return (
    <>
      <h1>siginUP</h1>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Minima itaque
        quia eligendi blanditiis veritatis nihil voluptate fuga, nesciunt iure
        non tenetur aut est nam voluptas aliquam mollitia velit repellendus
        tempore?
      </p>
    </>
  );
}
