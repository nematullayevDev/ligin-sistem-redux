import { FaRegUser } from "react-icons/fa";
import { IoMailOutline } from "react-icons/io5";
import { FaLock } from "react-icons/fa6";
import { BrowserRouter, Link, Route, Router, Routes } from "react-router-dom";
import google from "../public/google.svg";
// import { siginUP } from "./page/siginUp";
// import { welPage } from "./page/welPage";

function App() {
  return (
    <div className="">
      <BrowserRouter>
        <div className="w-[550px] mx-auto flex flex-col items-center mt-8 bg-white  rounded-[10px]">
          <h1 className="text-3xl font-bold pt-[10px]">Let’s go!</h1>
          <form className="mt-[30px]">
            {/* NAME INPUT */}
            <div className="w-full ]">
              <h3 className="mb-[10px] text-[17px]">Full Name</h3>
              <div className="flex items-center bg-white gap-2 border-solid border-2 rounded-[10px] border-[#797979">
                <FaRegUser className="text-[#797979] ml-[10px] " />
                <input
                  type="text"
                  name=""
                  id=""
                  className="w-[420px] py-[14px] outline-none pr-[10px]"
                  placeholder="Full Name..."
                />
              </div>
            </div>

            {/* MAIL INPUT */}
            <div className="w-full mt-[20px]">
              <h3 className="mb-[10px] text-[17px]">Email</h3>
              <div className="flex items-center bg-white gap-2 border-solid border-2 rounded-[10px] border-[#797979">
                <IoMailOutline className="text-[#797979] ml-[10px] " />
                <input
                  type="text"
                  name=""
                  id=""
                  className="w-[420px] py-[14px] outline-none pr-[10px]"
                  placeholder="Email..."
                />
              </div>
            </div>

            {/* PASSWORD INPUT */}
            <div className="w-full mt-[20px]">
              <h3 className="mb-[10px] text-[17px]">Choose Password</h3>
              <div className="flex items-center bg-white gap-2 border-solid border-2 rounded-[10px] border-[#797979">
                <FaLock className="text-[#797979] ml-[10px] " />
                <input
                  type="text"
                  name=""
                  id=""
                  className="w-[420px] py-[14px] outline-none pr-[10px]"
                  placeholder="Minimum 8 characters..."
                />
              </div>
            </div>
            {/* BUTTON  */}
            <button className="w-[455px] mt-[30px] rounded-[10px] bg-gradient-to-r from-[#FFA7A7] to-[#FF014E] py-[20px] hover: hover:bg-gradient-to-l transition duration-1000  text-white text-xl font-bold ">
              Sign Up
            </button>
          </form>

          {/* GOOGLE BUTTON */}
          <button className="w-[455px]  border-solid border-2 rounded-[10px] border-[#797979] py-[20px] mt-4 font-[600] text-[#797979] relative">
            <div className="flex items-center justify-center gap-4">
              <img src={google} alt="" width={29} height={29} />
              Sign Up with Google
            </div>
          </button>
          <span className="text-xl font-[400] mt-[20px] mb-[20px]">
            or login with SSO
          </span>
          {/* FOOTER */}
          <div className="border-solid border  border-[#9f9e9e] w-full"></div>
          <span className="w-[450px] text-[12px] p-[10px]">
            By lobby the button above, you agree to our Terms of Service and
            Privacy Policy.
          </span>
        </div>
        <Routes>
          {/* <Router path="/siginup" element={siginUP} />
          <Router path="/welcome" element={welPage} /> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
